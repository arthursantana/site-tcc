#!/usr/bin/env bash
#JULIA_LOAD_PATH="./" julia demoFortune.jl
#JULIA_LOAD_PATH="./" julia fortuneTime.jl
JULIA_LOAD_PATH="./" julia demoLloyd.jl
#JULIA_LOAD_PATH="./" julia gradientDescent.jl
#JULIA_LOAD_PATH="./" julia benchmark.jl
