Julia implementations of Fortune's algorithm, Lloyd's algorithm and gradient descent applied to the construction of Centroidal Voronoi Tesselations.

This is the source code that goes with my undergraduate thesis, available (in portuguese) at:
https://linux.ime.usp.br/~arthur/mac0499/

Bug reports, style enhancements and documentation corrections are very welcome.
